// Initialize Lenis
const lenis = new Lenis({
    duration: 1.2,
    easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)) // optional for smoother curve
});

// Sync ScrollTrigger with Lenis
gsap.registerPlugin(ScrollTrigger);

// Lenis scroll update on each frame
function raf(time) {
    lenis.raf(time);
    ScrollTrigger.update();
    // Update Bootstrap ScrollSpy position
    bootstrap.ScrollSpy.getInstance(document.body)?.refresh()
    requestAnimationFrame(raf);
}
requestAnimationFrame(raf);

// Feature section scroll animation
const featureClasses = [
    'first-list',
    'second-list',
    'third-list',
    'fourth-list',
    'fifth-list',
    'sixth-list'
];

const setActiveFeature = (selector) => {
    document.querySelectorAll('.sz-features-content-list').forEach(el => {
        el.classList.remove("sz-active-list");
    });
    document.querySelector(selector)?.classList.add("sz-active-list");
};
if (window.innerWidth > 768) {
    const t1 = gsap.timeline({
        scrollTrigger: {
            trigger: ".sz-features-animation",
            start: "top 10%",
            end: "bottom 0%",
            pin: true,
            scrub: true,
            // markers: true,
        }
    });

    featureClasses.forEach((cls, index) => {
        const selector = `.sz-features-content-list.${cls}`;
        t1.call(() => setActiveFeature(selector), null, index);
        t1.to({}, { duration: 1 });
    });
}



document.addEventListener("DOMContentLoaded", function () {
    gsap.registerPlugin(ScrollTrigger);

    const offset = 80; // Fixed header height
    const navLinks = document.querySelectorAll(".nav-link[href^='#']");

    // Store created triggers to avoid duplicates
    const createdTriggers = new Set();

    function setActiveLink(id) {
        navLinks.forEach(link => {
            const href = link.getAttribute("href");
            link.classList.toggle("active", href === `#${id}`);
        });
    }

    navLinks.forEach(link => {
        const targetId = link.getAttribute("href").substring(1);
        const section = document.getElementById(targetId);

        // Prevent multiple triggers for the same section
        if (section && !createdTriggers.has(targetId)) {
            createdTriggers.add(targetId);

            ScrollTrigger.create({
                trigger: section,
                start: `top+=${-offset} center`,
                end: "bottom center",
                onToggle: self => {
                    if (self.isActive) {
                        setActiveLink(targetId);
                    }
                }
                // markers: true
            });
        }
    });
    // Smooth scroll with offset
    navLinks.forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const targetId = this.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                const scrollPos = targetElement.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top: scrollPos, behavior: "smooth" });

                // Force active class manually right after scroll starts
                setActiveLink(targetId);
            }
        });
    });
});


